# PHP-Login System using Bootstrap v3.3.7
Simple PHP Login System using Session variables

**Clone the Repository**
Clone this repo using ```$ git clone https://github.com/KudosAbhay/PHP-Login.git```
<br />

![Alt text](PHP-Login-index.png?raw=true "index.php")
![Alt text](PHP-Login-second_page.png?raw=true "second_page.php")
