<?php

include_once '../../database/dbConnect/db.php';

class session extends DB{

    //Obtiene el acceso a la tabla de usuario verificando si es correcto
    function Login($user, $pass){
        $query = $this->connect()->prepare('SELECT * FROM admin_user WHERE username = :user AND password = :pass');
        $query->execute(['user' => $user, 'pass' => md5($pass)]);
        return $query;
    }

    //valida el token de autenticacion
    function valToken($token){
        $query = $this->connect()->prepare('SELECT * FROM sessions WHERE token = :token');
        $query->execute(['token' => $token]);
        if($query->rowCount() >= 1){
            return true;
        }
        else{
            return false;
        }
    }

    //retorna el id del usuario especifico en la session
    function getIDUserToken($token)
    {
        $query = $this->connect()->prepare('SELECT * FROM sessions WHERE token = :token');
        $query->execute(['token' => $token]);
        if($query->rowCount() >= 1){
            $row = $query->fetch();
            return $row["id_usuario"];
        }
        else{
            return 0;
        }
    }

    //borra la session del usuario
    function delSession($token){
        $query = $this->connect()->prepare('DELETE FROM `sessions` WHERE token = :token');
        $query->execute(['token' => $token]);
        return true;
    }

    //iserta el token para el usuario que acaba de iniciar session.
    function generateSession($token, $id){
        $query = $this->connect()->prepare('INSERT INTO `sessions` (token, id_usuario) VALUES (:token, :id)');
        $query->execute(['token' => $token, 'id' => $id]);
        return $query;
    }

}

?>