<?php

include_once '../../database/dbConnect/db.php';

class pages extends DB{

    //retorna paciente por id
    function getRowsID($id){
        $query = $this->connect()->prepare('SELECT * FROM table_data WHERE id = :id');
        $query->execute(['id' => $id]);
        return $query;
    }

    //retorna la lista de pacientes
    function getRowsAll()
    {
        $query = $this->connect()->prepare('SELECT * FROM table_data');
        $query->execute();
        return $query;
    }

    //retorna lista custom de consulta
    function getRowsCustom($DataSearch){
        $query = $this->connect()->prepare("SELECT * FROM table_data WHERE id LIKE '%{$DataSearch}%' 
                                            OR urldata_cb LIKE '%{$DataSearch}%' 
                                            OR nombres LIKE '%{$DataSearch}%'
                                            OR apellido1 LIKE '%{$DataSearch}%'
                                            OR apellido2 LIKE '%{$DataSearch}%'
                                            OR apellidos LIKE '%{$DataSearch}%'
                                            OR fechaNac LIKE '%{$DataSearch}%'
                                            OR sexo LIKE '%{$DataSearch}%'
                                            OR edad LIKE '%{$DataSearch}%'
                                            OR telefono LIKE '%{$DataSearch}%'
                                            OR direccion LIKE '%{$DataSearch}%'
                                            OR calle LIKE '%{$DataSearch}%'
                                            OR casa LIKE '%{$DataSearch}%'
                                            OR colegio LIKE '%{$DataSearch}%'
                                            OR provincia LIKE '%{$DataSearch}%'
                                            OR municipio LIKE '%{$DataSearch}%'
                                            OR municipioElectoral LIKE '%{$DataSearch}%'
                                            OR distrito_municipal LIKE '%{$DataSearch}%'
                                            OR CodigoRecinto LIKE '%{$DataSearch}%'
                                            OR Recinto LIKE '%{$DataSearch}%'
                                            OR ciudad LIKE '%{$DataSearch}%'
                                            OR sector LIKE '%{$DataSearch}%'
                                            OR LugarTrabajo LIKE '%{$DataSearch}%'
                                            OR MesSalario LIKE '%{$DataSearch}%'
                                            OR Salario LIKE '%{$DataSearch}%'
                                            OR IdProvincia LIKE '%{$DataSearch}%'
                                            OR IdMunicipio LIKE '%{$DataSearch}%'
                                            OR codigoCiudad LIKE '%{$DataSearch}%'
                                            OR idDistritoMunicipal LIKE '%{$DataSearch}%'
                                            OR CodigoCircunscripcion LIKE '%{$DataSearch}%'
                                            OR CodigoColegio LIKE '%{$DataSearch}%'
                                            OR codigoSector LIKE '%{$DataSearch}%'
                                            OR create_date LIKE '%{$DataSearch}%'
                                            OR update_date LIKE '%{$DataSearch}%'
                                            OR ip LIKE '%{$DataSearch}%'
                                            OR status LIKE '%{$DataSearch}%'
                                            ");
        $query->execute(['dataS' => $DataSearch]);
        return $query;
    }

}

?>