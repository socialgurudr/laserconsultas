<?php

include_once '../../database/funciones/session.php';

if(isset($_POST['token'])){
    $token = $_POST['token'];

    $reponse = array();
    $session = new session();
    $res = $session->delSession($token);
    if($res){
        $reponse['error'] = "false";
        $reponse['msg'] = "borrado";
        echo json_encode($reponse);
    }
    else{
        $reponse["error"] = "True";
        $reponse["msg"] = "error al borrar la session";
        echo json_encode($reponse);
    }
}

?>