<?php

include_once '../../database/funciones/session.php';

if(isset($_POST['user']) && isset($_POST['pass'])){
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $login = array();
    $session = new session();
    $res = $session->Login($user, $pass);
    if($res->rowCount() == 1){
        $row = $res->fetch();
        $login["token"] = bin2hex(random_bytes(32));
        $session->generateSession($login["token"], $row["id"]);
        echo json_encode($login);
    }
    else{
        $result = array();
        $result["error"] = "True";
        $result["msg"] = "No existe ese usuario";
        echo json_encode($result);
    }
}
else{
    $result = array();
    $result["error"] = "True";
    $result["msg"] = "Faltan parametros";
    echo json_encode($result);
}

?>