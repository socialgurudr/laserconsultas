<?php

header('Content-Type: application/json');

include_once '../../database/funciones/pages.php';
include_once '../../database/funciones/session.php';

if(isset($_POST['token'])){
    $token = $_POST['token'];
    $DataCustom = (array_key_exists('data', $_POST))? $_POST['data']: "";
    
    if($DataCustom == ""){
        $result = array();
        $result["error"] = "True";
        $result["msg"] = "Faltan parametros de consulta";
        echo json_encode($result);
        return;
    }

    $reponse = array();
    $session = new session();
    $stateSessions = $session->valToken($token);
    if($stateSessions){
        if(strpos($DataCustom, ",")){
            $id=explode(",",$DataCustom);
            foreach($id as $unico){
                $result[$unico] = getDataUnique($unico);
            }
            echo json_encode($result);
        }
        else{
            $pages = new pages();
            $res = $pages->getRowsCustom($DataCustom);
            if($res->rowCount() > 0){
                echo json_encode($res->fetchAll());
            }
            else{
                $result = array();
                $result["error"] = "True";
                $result["msg"] = "sin datos";
                echo json_encode($result);
            }
        }
    }
    else{
        $result = array();
        $result["error"] = "True";
        $result["msg"] = "error token vacio";
        echo json_encode($result);
    }
}
else{
    $result = array();
    $result["error"] = "True";
    $result["msg"] = "faltan parametros";
    echo json_encode($result);
}


function getDataUnique($unico){
    $AUnico = array();
    $pages = new pages();
    $res = $pages->getRowsCustom($unico);
    if($res->rowCount() >= 1){
        array_push($AUnico, $res->fetchAll());
    }
    return $AUnico;
}

?>